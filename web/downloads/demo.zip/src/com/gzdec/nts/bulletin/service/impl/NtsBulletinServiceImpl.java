
package com.gzdec.nts.bulletin.service.impl;

import com.gzdec.nts.bulletin.dao.NtsBulletinDao;
import com.gzdec.nts.bulletin.service.inter.NtsBulletinService;

/**
 * @author ����ǫ
 */
public class NtsBulletinServiceImpl extends NtsBulletinRESTServiceImpl implements NtsBulletinService{
	private NtsBulletinDao ntsBulletinDao;

	public NtsBulletinDao getNtsBulletinDao() {
		return ntsBulletinDao;
	}

	public void setNtsBulletinDao(NtsBulletinDao ntsBulletinDao) {
		this.ntsBulletinDao = ntsBulletinDao;
	}
}
	