
package com.gzdec.nts.bulletin.service.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import com.gzdec.nts.bulletin.dao.NtsBulletinRESTDao;
import com.gzdec.nts.bulletin.service.inter.NtsBulletinRESTService;
import com.gzdec.nts.bulletin.to.NtsBulletinTo;
import com.gzdec.nts.util.AppUtil;

import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

/**
 * @author ����ǫ
 */
public class NtsBulletinRESTServiceImpl implements NtsBulletinRESTService{
	private NtsBulletinRESTDao ntsBulletinRESTDao;
	
	public NtsBulletinRESTDao getNtsBulletinRESTDao() {
		return ntsBulletinRESTDao;
	}

	public void setNtsBulletinRESTDao(NtsBulletinRESTDao ntsBulletinRESTDao) {
		this.ntsBulletinRESTDao = ntsBulletinRESTDao;
	}

	public int create(Map<String, String> valueMap) {
		valueMap.put("bulletinId", UniqueIDGenerator.getUUID());
		return this.ntsBulletinRESTDao.create(this.mapToTo(valueMap));
	}

	public NtsBulletinTo find(Map<String, String> valueMap) {
		return this.findByFilter(valueMap);
	}
	
	public NtsBulletinTo findById(Map<String, String> valueMap) {
		String bulletinId = StringUtils.trimToEmpty(valueMap.get("bulletinId"));
		if("".equals(bulletinId)){
			return new NtsBulletinTo();
		}
		return this.findByFilter(valueMap);
	}
	
	public NtsBulletinTo findByFilter(Map<String, String> valueMap) {
		return this.ntsBulletinRESTDao.find(this.mapToTo(valueMap));
	}

	public List<NtsBulletinTo> findAll(Map<String, String> valueMap) {
		return this.ntsBulletinRESTDao.findAll(this.mapToTo(valueMap));
	}

	public List<NtsBulletinTo> findByPage(Map<String, String> valueMap,
			Pagination pagination) {
		return this.ntsBulletinRESTDao.findByPage(this.mapToTo(valueMap), pagination);
	}

	public int modify(Map<String, String> valueMap) {
		return this.ntsBulletinRESTDao.modify(this.mapToTo(valueMap));
	}

	public int remove(Map<String, String> valueMap) {
		String bulletinIds = StringUtils.trimToEmpty(valueMap.get("deleteBulletinId"));
		if(!"".equals(bulletinIds)){
			String[] bulletinIdArr = bulletinIds.split(", ");
			if(null != bulletinIdArr && bulletinIdArr.length > 0){
				List<NtsBulletinTo> list = new ArrayList<NtsBulletinTo>();
				for(int i = 0; i < bulletinIdArr.length; i++){
					String bulletinId = bulletinIdArr[i];
					Map<String, String> toMap = new HashMap<String, String>();
					toMap.put("bulletinId", bulletinId);
					toMap.put("isDeleted", "Y");
					list.add(this.mapToTo(toMap));
				}
				return this.ntsBulletinRESTDao.remove(list);
			}
		}
		return -1;
	}
	
	public NtsBulletinTo mapToTo(Map<String, String> valueMap){
		NtsBulletinTo to = new NtsBulletinTo();
		
		
		String bulletinId = StringUtils.trimToEmpty(valueMap.get("bulletinId"));
		
		String title = StringUtils.trimToEmpty(valueMap.get("title"));
		
		String bulletinDesc = StringUtils.trimToEmpty(valueMap.get("bulletinDesc"));
		
		String bulletinCategory = StringUtils.trimToEmpty(valueMap.get("bulletinCategory"));
		
		String content = StringUtils.trimToEmpty(valueMap.get("content"));
		
		String attchmentName = StringUtils.trimToEmpty(valueMap.get("attchmentName"));
		
		String attchment = StringUtils.trimToEmpty(valueMap.get("attchment"));
		
		String hypelinkName = StringUtils.trimToEmpty(valueMap.get("hypelinkName"));
		
		String hypelink = StringUtils.trimToEmpty(valueMap.get("hypelink"));
		
		String createdBy = StringUtils.trimToEmpty(valueMap.get("createdBy"));
		
		String updatedBy = StringUtils.trimToEmpty(valueMap.get("updatedBy"));
		
		String createdDt = StringUtils.trimToEmpty(valueMap.get("createdDt"));
		
		String updatedDt = StringUtils.trimToEmpty(valueMap.get("updatedDt"));
		
		String isDeleted = StringUtils.trimToEmpty(valueMap.get("isDeleted"));
		
	    if(!"".equals(bulletinId)){
		    to.setBulletinId(bulletinId);
	    }	
			
	    if(!"".equals(title)){
		    to.setTitle(title);
	    }	
			
	    if(!"".equals(bulletinDesc)){
		    to.setBulletinDesc(bulletinDesc);
	    }	
			
	    if(!"".equals(bulletinCategory)){
		    to.setBulletinCategory(bulletinCategory);
	    }	
			
	    if(!"".equals(content)){
		    to.setContent(content);
	    }	
			
	    if(!"".equals(attchmentName)){
		    to.setAttchmentName(attchmentName);
	    }	
			
	    if(!"".equals(attchment)){
		    to.setAttchment(attchment);
	    }	
			
	    if(!"".equals(hypelinkName)){
		    to.setHypelinkName(hypelinkName);
	    }	
			
	    if(!"".equals(hypelink)){
		    to.setHypelink(hypelink);
	    }	
			
	    if(!"".equals(createdBy)){
		    to.setCreatedBy(createdBy);
	    }	
			
	    if(!"".equals(updatedBy)){
		    to.setUpdatedBy(updatedBy);
	    }	
			
		if (!"".equals(createdDt)) {
			try {
				to.setCreatedDt(AppUtil.toTimestamp(createdDt));
			}
			catch (ParseException e) {
				e.printStackTrace();
			}
		}				
			
		if (!"".equals(updatedDt)) {
			try {
				to.setUpdatedDt(AppUtil.toTimestamp(updatedDt));
			}
			catch (ParseException e) {
				e.printStackTrace();
			}
		}				
			
	    if(!"".equals(isDeleted)){
		    to.setIsDeleted(isDeleted);
	    }	
			

		return to;
	}
}
	