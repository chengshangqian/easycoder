
package com.gzdec.nts.bulletin.actions;

import com.gzdec.nts.bulletin.service.inter.NtsBulletinService;
import com.gzdec.nts.util.AppUtil;

import com.gzdec.framework.action.BaseAction;

/**
 * @author ����ǫ
 */
public class NtsBulletinAction extends BaseAction{
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -19600611L;
	
	private NtsBulletinService ntsBulletinService;
	
	public NtsBulletinService getNtsBulletinService() {
		return ntsBulletinService;
	}
	
	public void setNtsBulletinService(NtsBulletinService ntsBulletinService) {
		this.ntsBulletinService = ntsBulletinService;
	}
	
	/**
	 * Index
	 * @return
	 */
	public String index(){
		this.resultList = this.ntsBulletinService.findByPage(this.formMap,this.pagination);
		return SUCCESS;
	}

	/**
	 * Query List
	 * @return
	 */
	public String findAll(){
		this.resultList = this.ntsBulletinService.findAll(this.formMap);
		return SUCCESS;
	}
	
	/**
	 * Query Page List
	 * @return
	 */
	@SuppressWarnings("unchecked") 
	public String findByPage() throws Exception{
	    this.resultMap.putAll(this.formMap);
	    	    	
		this.resultList = this.ntsBulletinService.findByPage(this.formMap,this.pagination);
		return SUCCESS;
	}
	
	/**
	 * Ready To Create Or Modify
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String doInput(){
		this.resultMap.put("ntsBulletinTo", this.ntsBulletinService.findById(this.formMap));
		return SUCCESS;
	}
	
	/**
	 * Creating
	 * @return
	 */
	public String create(){
		this.ntsBulletinService.create(this.formMap);
		return SUCCESS;
	}
	
	/**
	 * Modifing
	 * @return
	 */
	public String modify(){
		this.ntsBulletinService.modify(this.formMap);
		return SUCCESS;
	}
	
	/**
	 * Deleting
	 * @return
	 */
	public String remove(){
		this.ntsBulletinService.remove(this.formMap);
		return SUCCESS;
	}
}
	