
package com.gzdec.nts.bulletin.to;

/**
 * @author ����ǫ
 */
public class NtsBulletinTo {
	
	private java.lang.String bulletinId;
	
	private java.lang.String title;
	
	private java.lang.String bulletinDesc;
	
	private java.lang.String bulletinCategory;
	
	private java.lang.String content;
	
	private java.lang.String attchmentName;
	
	private java.lang.String attchment;
	
	private java.lang.String hypelinkName;
	
	private java.lang.String hypelink;
	
	private java.lang.String createdBy;
	
	private java.lang.String updatedBy;
	
	private java.sql.Timestamp createdDt;
	
	private java.sql.Timestamp updatedDt;
	
	private java.lang.String isDeleted;
	
	public java.lang.String getBulletinId() {
		return bulletinId;
	}
	public void setBulletinId(java.lang.String bulletinId) {
		this.bulletinId = bulletinId;
	}
	
	public java.lang.String getTitle() {
		return title;
	}
	public void setTitle(java.lang.String title) {
		this.title = title;
	}
	
	public java.lang.String getBulletinDesc() {
		return bulletinDesc;
	}
	public void setBulletinDesc(java.lang.String bulletinDesc) {
		this.bulletinDesc = bulletinDesc;
	}
	
	public java.lang.String getBulletinCategory() {
		return bulletinCategory;
	}
	public void setBulletinCategory(java.lang.String bulletinCategory) {
		this.bulletinCategory = bulletinCategory;
	}
	
	public java.lang.String getContent() {
		return content;
	}
	public void setContent(java.lang.String content) {
		this.content = content;
	}
	
	public java.lang.String getAttchmentName() {
		return attchmentName;
	}
	public void setAttchmentName(java.lang.String attchmentName) {
		this.attchmentName = attchmentName;
	}
	
	public java.lang.String getAttchment() {
		return attchment;
	}
	public void setAttchment(java.lang.String attchment) {
		this.attchment = attchment;
	}
	
	public java.lang.String getHypelinkName() {
		return hypelinkName;
	}
	public void setHypelinkName(java.lang.String hypelinkName) {
		this.hypelinkName = hypelinkName;
	}
	
	public java.lang.String getHypelink() {
		return hypelink;
	}
	public void setHypelink(java.lang.String hypelink) {
		this.hypelink = hypelink;
	}
	
	public java.lang.String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(java.lang.String createdBy) {
		this.createdBy = createdBy;
	}
	
	public java.lang.String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(java.lang.String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public java.sql.Timestamp getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(java.sql.Timestamp createdDt) {
		this.createdDt = createdDt;
	}
	
	public java.sql.Timestamp getUpdatedDt() {
		return updatedDt;
	}
	public void setUpdatedDt(java.sql.Timestamp updatedDt) {
		this.updatedDt = updatedDt;
	}
	
	public java.lang.String getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(java.lang.String isDeleted) {
		this.isDeleted = isDeleted;
	}
	
}
	