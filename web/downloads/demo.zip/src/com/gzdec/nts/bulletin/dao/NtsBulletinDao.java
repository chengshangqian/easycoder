
package com.gzdec.nts.bulletin.dao;

import com.gzdec.framework.dao.SqlMapBaseDao;

/**
 * @author ����ǫ
 */
public class NtsBulletinDao extends SqlMapBaseDao{

}
	