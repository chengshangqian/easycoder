
package com.gzdec.nts.bulletin.service.inter;

import java.util.List;
import java.util.Map;

import com.gzdec.nts.bulletin.to.NtsBulletinTo;

import com.gzdec.framework.page.Pagination;

/**
 * @author ����ǫ
 */
public interface NtsBulletinRESTService {

	/**
	 * Query List
	 * @param valueMap
	 * @return
	 */
	public List<NtsBulletinTo> findAll(Map<String,String> valueMap);
	
	/**
	 * Query Page List
	 * @param valueMap
	 * @return
	 */
	public List<NtsBulletinTo> findByPage(Map<String,String> valueMap,Pagination pagination);
	
	/**
	 * Get A Record
	 * @param valueMap
	 * @return
	 */
	public NtsBulletinTo find(Map<String,String> valueMap);
	
	/**
	 * Get A Record
	 * @param valueMap
	 * @return
	 */
	public NtsBulletinTo findById(Map<String,String> valueMap);
	
	/**
	 * Get A Record
	 * @param valueMap
	 * @return
	 */
	public NtsBulletinTo findByFilter(Map<String,String> valueMap);
	
	/**
	 * Creating
	 * @param valueMap
	 * @return
	 */
	public int create(Map<String,String> valueMap);	
	
	/**
	 * Modifing
	 * @param valueMap
	 * @return
	 */
	public int modify(Map<String,String> valueMap);	
	
	/**
	 * Deleting
	 * @param valueMap
	 * @return
	 */
	public int remove(Map<String,String> valueMap);
	
	/**
	 * Map mapping to To
	 * @param valueMap
	 * @return
	 */	
	public NtsBulletinTo mapToTo(Map<String,String> valueMap);

}
	