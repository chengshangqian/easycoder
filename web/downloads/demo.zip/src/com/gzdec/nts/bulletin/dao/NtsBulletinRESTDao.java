
package com.gzdec.nts.bulletin.dao;

import java.util.ArrayList;
import java.util.List;

import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;
import com.gzdec.nts.bulletin.to.NtsBulletinTo;

/**
 * @author ����ǫ
 */
public class NtsBulletinRESTDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<NtsBulletinTo> findAll(NtsBulletinTo to){
		return this.queryForList("nts.bulletin.ntsBulletin.query", to);
	}
	
	/**
	 * Query Page List
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<NtsBulletinTo> findByPage(NtsBulletinTo to,Pagination pagination){
		return this.queryForList("nts.bulletin.ntsBulletin.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @param to
	 * @return
	 */
	public NtsBulletinTo find(NtsBulletinTo to){
		return (NtsBulletinTo)this.queryForObject("nts.bulletin.ntsBulletin.query", to);
	}
	
	/**
	 * Creating
	 * @param to
	 * @return
	 */
	public int create(NtsBulletinTo to){
		try{
			this.insert("nts.bulletin.ntsBulletin.create", to);
			return 1;
		}catch(Exception ex){
			System.err.println("Add Error : ");
			ex.printStackTrace();
		}
		return -1;
	}
	
	/**
	 * Modify
	 * @param to
	 * @return
	 */
	public int modify(NtsBulletinTo to){
		try{
			return this.update("nts.bulletin.ntsBulletin.modify", to);
		}catch(Exception ex){
			System.err.println("Modify Error : ");
			ex.printStackTrace();
		}
		return -1;
	}
	
	/**
	 * Deleting
	 * @param to
	 * @return
	 */
	public int remove(NtsBulletinTo to){
		try{
			List<NtsBulletinTo> list = new ArrayList<NtsBulletinTo>();
			list.add(to);
			return this.remove(list);
		}catch(Exception ex){
			System.err.println("Delete Error : ");
			ex.printStackTrace();
		}
		return -1;
	}
	
	/**
	 * Deleting List
	 * @param list
	 * @return
	 */
	public int remove(List<NtsBulletinTo> list){
		int count = 0;
		if(null == list || list.size() <= 0){
			return count;
		}
		for(int i = 0; i < list.size(); i++){
		    NtsBulletinTo to = list.get(i);
			count += this.delete("nts.bulletin.ntsBulletin.remove", to);
		}
		return count;
	}
}
	