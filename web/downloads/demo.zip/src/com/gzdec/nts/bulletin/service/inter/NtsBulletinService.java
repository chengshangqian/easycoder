
package com.gzdec.nts.bulletin.service.inter;

/**
 * @author ����ǫ
 */
public interface NtsBulletinService extends NtsBulletinRESTService{

}
	