
/**
 * @author ����ǫ
 */
 
  $(function(){
	 var xhEditorUploadUrl = $('#editorUploadAction').val();
	 var xhEditors = [];
	 
 	 xhEditors.push('bulletinDesc');
 	 
 	 xhEditors.push('content');
 	 
 	 
     var rules = {};
 	 
 	 rules['formMap.title'] = {required:true};
 	 
 	 rules['formMap.bulletinDesc'] = {required:true};
 	 
 	 rules['formMap.bulletinCategory'] = {required:true,number:true};
 	 
 	  	 
	 var cfg = {
		backIndex : '/nts/bulletin/ntsBulletin/index.do'
		//,backBt : 'backBt'
		//,inputForm : 'inputForm'
		,xhEditors : xhEditors
		,rules : rules
		,uploadCfg : {
			upLinkUrl:xhEditorUploadUrl
			//,upLinkExt:"zip,rar,txt"
			,upImgUrl:xhEditorUploadUrl
			//,upImgExt:"jpg,jpeg,gif,png,bmg"
			,upFlashUrl:xhEditorUploadUrl
			//,upFlashExt:"swf"
			,upMediaUrl:xhEditorUploadUrl
			//,upMediaExt:"wmv,avi,wma,mp3,mid"
		}
		//,uploadEnabled : true
	    //,requiredErrorHtml : '<span style="font-weight:bold; color:#F00;">&nbsp;*</span>'
	 };
	 var ntsBulletinMerger = new ESCoder.Merger(cfg);
	 ntsBulletinMerger.start();
 });
	