
/**
 * @author ����ǫ
 */
 
  $(function(){
    var rules = {};
 	
 	rules['formMap.bulletinCategory'] = {number:true};
 	
 	    
 	var cfg = {
 		 queryAction : '/nts/bulletin/ntsBulletin/findByPage.do'
 		 ,deleteAction : '/nts/bulletin/ntsBulletin/remove.do'
 		 ,createAction : '/nts/bulletin/ntsBulletin/doInput.do'
 		 ,rules : rules 			
		 //,createBt : 'createBt'
		 //,deleteSelected : 'deleteSelected'
		 //,allCheckBox : 'allCheckBox'
		 //,deleteSelector : 'a.delete'
		 //,queryForm : 'queryForm'
		 //,selectedTips : '��ѡ��һ����¼!'
 	     //,deleteSelectedConfirmTips : 'ȷ��ɾ����ѡ��¼��?'
	     //,deleteConfirmTips : 'ȷ��ɾ������Ϣ��?'	 
 	};
 	var ntsBulletinManager = new ESCoder.Manager(cfg);
 	ntsBulletinManager.start(); 	
 });
	