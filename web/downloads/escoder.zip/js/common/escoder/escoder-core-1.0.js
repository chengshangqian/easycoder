/**
 * ESCoder Library 1.0
 * Copyright 2011, Vin Cheng(����ǫ),lhx222@gmail.com
 * Dual licensed under the MIT or GPL Version 2 licenses
 * Date: 2011/11/2
 */
 var ESCoder = window.ESCoder = {
	version : '1.0',
	date : '2011/11/2',
	author : 'Vin Cheng(����ǫ)',
	email : 'lhx222@gmail.com',
	page : '',
	license : 'MIT or GPL2',
	copyright : 'Copyright 2011'
 };